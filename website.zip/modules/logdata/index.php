<?php
if (!defined('FLUX_ROOT')) exit;

$this->loginRequired();

$title = 'Log Data';
?>
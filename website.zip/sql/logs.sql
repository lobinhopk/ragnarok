-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 24-Fev-2016 às 02:17
-- Versão do servidor: 5.7.11
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `logs`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `atcommandlog`
--

CREATE TABLE `atcommandlog` (
  `atcommand_id` mediumint(9) UNSIGNED NOT NULL,
  `atcommand_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `account_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `char_name` varchar(25) NOT NULL DEFAULT '',
  `map` varchar(11) NOT NULL DEFAULT '',
  `command` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `atcommandlog`
--

INSERT INTO `atcommandlog` (`atcommand_id`, `atcommand_date`, `account_id`, `char_id`, `char_name`, `map`, `command`) VALUES
(1, '2016-02-17 01:47:43', 2000000, 150000, 'Alan', 'housein', '@save'),
(2, '2016-02-17 01:47:47', 2000000, 150000, 'Alan', 'housein', '@save'),
(3, '2016-02-17 01:47:54', 2000000, 150000, 'Alan', 'housein', '@repairall'),
(4, '2016-02-17 01:48:26', 2000000, 150000, 'Alan', 'housein', '@cash 100000'),
(5, '2016-02-17 01:49:17', 2000000, 150000, 'Alan', 'pallet', '@kick Alan'),
(6, '2016-02-17 01:50:18', 2000000, 150000, 'Alan', 'housein', '@warp housein 115 59'),
(7, '2016-02-17 01:51:20', 2000000, 150000, 'Alan', 'housein', '@refresh'),
(8, '2016-02-17 01:51:26', 2000000, 150000, 'Alan', 'housein', '@refresh npc'),
(9, '2016-02-17 02:13:16', 2000000, 150000, 'Alan', 'pallet', '@warp pallet'),
(10, '2016-02-17 02:13:19', 2000000, 150000, 'Alan', 'pallet', '@warp pallet'),
(11, '2016-02-17 02:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(12, '2016-02-17 02:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(13, '2016-02-17 02:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(14, '2016-02-17 02:34:38', 2000000, 150000, 'Alan', 'pallet', '@makehomun'),
(15, '2016-02-17 02:34:43', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2555'),
(16, '2016-02-17 02:46:45', 2000000, 150000, 'Alan', 'pallet', '@makehomun 254'),
(17, '2016-02-17 02:46:47', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2547'),
(18, '2016-02-17 02:46:50', 2000000, 150000, 'Alan', 'pallet', '@makehomun'),
(19, '2016-02-17 02:48:49', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2569'),
(20, '2016-02-17 02:50:24', 2000000, 150000, 'Alan', 'pallet', '@item masterball'),
(21, '2016-02-17 02:50:33', 2000000, 150000, 'Alan', 'pallet', '@item master_ball'),
(22, '2016-02-17 02:50:36', 2000000, 150000, 'Alan', 'pallet', '@item master ball'),
(23, '2016-02-17 02:50:47', 2000000, 150000, 'Alan', 'pallet', '@monster caterpie'),
(24, '2016-02-17 02:54:31', 2000000, 150000, 'Alan', 'pallet', '@makehomun'),
(25, '2016-02-17 02:54:35', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2567'),
(26, '2016-02-17 03:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(27, '2016-02-17 03:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(28, '2016-02-17 03:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(29, '2016-02-17 03:01:36', 2000000, 150000, 'Alan', 'pallet', '@item'),
(30, '2016-02-17 03:01:57', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2567'),
(31, '2016-02-17 03:08:59', 2000001, 150001, 'Alann', 'housein', '@save'),
(32, '2016-02-17 03:13:40', 2000000, 150000, 'Alan', 'pallet', '@makehomun'),
(33, '2016-02-17 03:13:58', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2956'),
(34, '2016-02-17 03:14:12', 2000000, 150000, 'Alan', 'pallet', '@makehomun 26593'),
(35, '2016-02-17 03:14:53', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510'),
(36, '2016-02-17 03:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(37, '2016-02-17 03:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(38, '2016-02-17 03:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(39, '2016-02-17 03:16:12', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510'),
(40, '2016-02-17 03:16:25', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510'),
(41, '2016-02-17 03:16:47', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510 '),
(42, '2016-02-17 03:17:16', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510 '),
(43, '2016-02-17 03:17:32', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510  '),
(44, '2016-02-17 03:17:48', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510  '),
(45, '2016-02-17 03:18:11', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510  '),
(46, '2016-02-17 03:18:28', 2000000, 150000, 'Alan', 'pallet', '@makehomun 2510   '),
(47, '2016-02-17 03:18:40', 2000000, 150000, 'Alan', 'pallet', '@item 690'),
(48, '2016-02-17 03:18:58', 2000000, 150000, 'Alan', 'housein', '@save'),
(49, '2016-02-17 03:19:16', 2000000, 150000, 'Alan', 'housein', '@item 690'),
(50, '2016-02-17 03:20:00', 2000000, 150000, 'Alan', 'pallet', '@cash'),
(51, '2016-02-17 03:20:03', 2000000, 150000, 'Alan', 'pallet', '@cash 100000'),
(52, '2016-02-17 03:20:29', 2000000, 150000, 'Alan', 'pallet', '@kick Alan'),
(53, '2016-02-17 03:21:43', 2000000, 150000, 'Alan', 'housein', '@warp housein 115 59'),
(54, '2016-02-17 03:23:25', 2000000, 150000, 'Alan', 'housein', '@job'),
(55, '2016-02-17 03:23:33', 2000000, 150000, 'Alan', 'housein', '@job 4045'),
(56, '2016-02-17 03:23:40', 2000000, 150000, 'Alan', 'housein', '@allskill'),
(57, '2016-02-17 03:24:21', 2000000, 150000, 'Alan', 'housein', '@hcolor *9'),
(58, '2016-02-17 03:24:24', 2000000, 150000, 'Alan', 'housein', '@hcolor 9'),
(59, '2016-02-17 03:24:29', 2000000, 150000, 'Alan', 'housein', '@hstyle 24'),
(60, '2016-02-17 03:24:31', 2000000, 150000, 'Alan', 'housein', '@hstyle 20'),
(61, '2016-02-17 03:24:36', 2000000, 150000, 'Alan', 'housein', '@hstyle 29'),
(62, '2016-02-17 03:24:38', 2000000, 150000, 'Alan', 'housein', '@hstyle 18'),
(63, '2016-02-17 03:24:39', 2000000, 150000, 'Alan', 'housein', '@hstyle 17'),
(64, '2016-02-17 03:24:41', 2000000, 150000, 'Alan', 'housein', '@hstyle 16'),
(65, '2016-02-17 03:24:42', 2000000, 150000, 'Alan', 'housein', '@hstyle 15'),
(66, '2016-02-17 03:24:43', 2000000, 150000, 'Alan', 'housein', '@hstyle 14'),
(67, '2016-02-17 03:24:44', 2000000, 150000, 'Alan', 'housein', '@hstyle 13'),
(68, '2016-02-17 03:24:45', 2000000, 150000, 'Alan', 'housein', '@hstyle 12'),
(69, '2016-02-17 03:24:46', 2000000, 150000, 'Alan', 'housein', '@hstyle 11'),
(70, '2016-02-17 03:24:48', 2000000, 150000, 'Alan', 'housein', '@hstyle 10'),
(71, '2016-02-17 03:24:49', 2000000, 150000, 'Alan', 'housein', '@hstyle 19'),
(72, '2016-02-17 03:24:50', 2000000, 150000, 'Alan', 'housein', '@hstyle 18'),
(73, '2016-02-17 03:24:51', 2000000, 150000, 'Alan', 'housein', '@hstyle 17'),
(74, '2016-02-17 03:24:53', 2000000, 150000, 'Alan', 'housein', '@hstyle 7'),
(75, '2016-02-17 03:24:54', 2000000, 150000, 'Alan', 'housein', '@hstyle 8'),
(76, '2016-02-17 03:24:55', 2000000, 150000, 'Alan', 'housein', '@hstyle 6'),
(77, '2016-02-17 03:24:57', 2000000, 150000, 'Alan', 'housein', '@hstyle 5'),
(78, '2016-02-17 03:24:58', 2000000, 150000, 'Alan', 'housein', '@hstyle 4'),
(79, '2016-02-17 03:24:59', 2000000, 150000, 'Alan', 'housein', '@hstyle 3'),
(80, '2016-02-17 03:25:00', 2000000, 150000, 'Alan', 'housein', '@hstyle 2'),
(81, '2016-02-17 03:25:01', 2000000, 150000, 'Alan', 'housein', '@hstyle 1'),
(82, '2016-02-17 03:25:03', 2000000, 150000, 'Alan', 'housein', '@hstyle 50'),
(83, '2016-02-17 03:25:51', 2000000, 150002, 'Alan', 'pallet', '@speed'),
(84, '2016-02-17 03:25:53', 2000000, 150002, 'Alan', 'pallet', '@speed 1'),
(85, '2016-02-17 03:26:03', 2000000, 150002, 'Alan', 'housein', '@warp housein 115 59'),
(86, '2016-02-17 03:26:20', 2000000, 150002, 'Alan', 'housein', '@speed 1'),
(87, '2016-02-17 03:26:28', 2000000, 150002, 'Alan', 'housein', '@hstyle 24'),
(88, '2016-02-17 03:26:32', 2000000, 150002, 'Alan', 'housein', '@hstyle 23'),
(89, '2016-02-17 03:26:33', 2000000, 150002, 'Alan', 'housein', '@hstyle 22'),
(90, '2016-02-17 03:26:34', 2000000, 150002, 'Alan', 'housein', '@hstyle 21'),
(91, '2016-02-17 03:26:36', 2000000, 150002, 'Alan', 'housein', '@hstyle 20'),
(92, '2016-02-17 03:26:37', 2000000, 150002, 'Alan', 'housein', '@hstyle 29'),
(93, '2016-02-17 03:26:40', 2000000, 150002, 'Alan', 'housein', '@hstyle 19'),
(94, '2016-02-17 03:26:41', 2000000, 150002, 'Alan', 'housein', '@hstyle 18'),
(95, '2016-02-17 03:26:42', 2000000, 150002, 'Alan', 'housein', '@hstyle 17'),
(96, '2016-02-17 03:26:43', 2000000, 150002, 'Alan', 'housein', '@hstyle 16'),
(97, '2016-02-17 03:26:44', 2000000, 150002, 'Alan', 'housein', '@hstyle 15'),
(98, '2016-02-17 03:26:46', 2000000, 150002, 'Alan', 'housein', '@hstyle 22'),
(99, '2016-02-17 03:26:47', 2000000, 150002, 'Alan', 'housein', '@hstyle 23'),
(100, '2016-02-17 03:26:48', 2000000, 150002, 'Alan', 'housein', '@hstyle 24'),
(101, '2016-02-17 03:26:49', 2000000, 150002, 'Alan', 'housein', '@hstyle 25'),
(102, '2016-02-17 03:26:50', 2000000, 150002, 'Alan', 'housein', '@hstyle 26'),
(103, '2016-02-17 03:26:51', 2000000, 150002, 'Alan', 'housein', '@hstyle 27'),
(104, '2016-02-17 03:26:52', 2000000, 150002, 'Alan', 'housein', '@hstyle 28'),
(105, '2016-02-17 03:26:53', 2000000, 150002, 'Alan', 'housein', '@hstyle 29'),
(106, '2016-02-17 03:26:54', 2000000, 150002, 'Alan', 'housein', '@hstyle 30'),
(107, '2016-02-17 03:26:55', 2000000, 150002, 'Alan', 'housein', '@hstyle 31'),
(108, '2016-02-17 03:26:57', 2000000, 150002, 'Alan', 'housein', '@hstyle 32'),
(109, '2016-02-17 03:26:58', 2000000, 150002, 'Alan', 'housein', '@hstyle 33'),
(110, '2016-02-17 03:26:59', 2000000, 150002, 'Alan', 'housein', '@hstyle 34'),
(111, '2016-02-17 03:27:01', 2000000, 150002, 'Alan', 'housein', '@hstyle 33'),
(112, '2016-02-17 03:27:05', 2000000, 150002, 'Alan', 'housein', '@hcolor 9'),
(113, '2016-02-17 03:27:10', 2000000, 150002, 'Alan', 'housein', '@job 4047'),
(114, '2016-02-17 03:27:15', 2000000, 150002, 'Alan', 'housein', '@job 4045'),
(115, '2016-02-17 03:27:20', 2000000, 150002, 'Alan', 'housein', '@ccolor 81'),
(116, '2016-02-17 03:27:22', 2000000, 150002, 'Alan', 'housein', '@ccolor 82'),
(117, '2016-02-17 03:27:23', 2000000, 150002, 'Alan', 'housein', '@ccolor 83'),
(118, '2016-02-17 03:27:24', 2000000, 150002, 'Alan', 'housein', '@ccolor 84'),
(119, '2016-02-17 03:27:25', 2000000, 150002, 'Alan', 'housein', '@ccolor 85'),
(120, '2016-02-17 03:27:33', 2000000, 150002, 'Alan', 'housein', '@repairall'),
(121, '2016-02-17 03:27:33', 2000000, 150002, 'Alan', 'housein', '@speed 150'),
(122, '2016-02-17 03:27:33', 2000000, 150002, 'Alan', 'housein', '@undisguise'),
(123, '2016-02-17 03:28:53', 2000000, 150003, 'Alan', 'pallet', '@speed 1'),
(124, '2016-02-17 03:29:00', 2000000, 150003, 'Alan', 'housein', '@warp housein 115 59'),
(125, '2016-02-17 03:29:16', 2000000, 150003, 'Alan', 'housein', '@repairall'),
(126, '2016-02-17 03:29:16', 2000000, 150003, 'Alan', 'housein', '@speed 150'),
(127, '2016-02-17 03:29:16', 2000000, 150003, 'Alan', 'housein', '@undisguise'),
(128, '2016-02-17 03:30:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(129, '2016-02-17 03:30:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(130, '2016-02-17 03:30:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(131, '2016-02-17 03:31:27', 2000000, 150003, 'Alan', 'housein', '@repairall'),
(132, '2016-02-17 03:31:27', 2000000, 150003, 'Alan', 'housein', '@speed 150'),
(133, '2016-02-17 03:31:27', 2000000, 150003, 'Alan', 'housein', '@undisguise'),
(134, '2016-02-17 03:31:29', 2000000, 150003, 'Alan', 'housein', '@repairall'),
(135, '2016-02-17 03:31:29', 2000000, 150003, 'Alan', 'housein', '@speed 150'),
(136, '2016-02-17 03:31:29', 2000000, 150003, 'Alan', 'housein', '@undisguise'),
(137, '2016-02-17 03:31:52', 2000000, 150003, 'Alan', 'housein', '@hcolor 9'),
(138, '2016-02-17 03:31:57', 2000000, 150003, 'Alan', 'housein', '@job'),
(139, '2016-02-17 03:32:11', 2000000, 150003, 'Alan', 'housein', '@job 4023'),
(140, '2016-02-17 03:32:18', 2000000, 150003, 'Alan', 'housein', '@job 4024'),
(141, '2016-02-17 03:32:23', 2000000, 150003, 'Alan', 'housein', '@ccolor 85'),
(142, '2016-02-17 03:32:29', 2000000, 150003, 'Alan', 'housein', '@speed 1'),
(143, '2016-02-17 03:36:19', 2000000, 150003, 'Alan', 'housein', '@item'),
(144, '2016-02-17 03:36:44', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(145, '2016-02-17 03:37:10', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(146, '2016-02-17 03:37:42', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(147, '2016-02-17 03:38:40', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(148, '2016-02-17 03:41:32', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(149, '2016-02-17 03:42:08', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(150, '2016-02-17 03:42:15', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(151, '2016-02-17 03:43:01', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(152, '2016-02-17 03:43:20', 2000000, 150003, 'Alan', 'housein', '@repairall'),
(153, '2016-02-17 03:43:20', 2000000, 150003, 'Alan', 'housein', '@speed 150'),
(154, '2016-02-17 03:43:20', 2000000, 150003, 'Alan', 'housein', '@undisguise'),
(155, '2016-02-17 03:45:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(156, '2016-02-17 03:45:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(157, '2016-02-17 03:45:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(158, '2016-02-17 03:45:22', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(159, '2016-02-17 03:45:38', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(160, '2016-02-17 03:45:38', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(161, '2016-02-17 03:45:38', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(162, '2016-02-17 03:47:25', 2000000, 150003, 'Alan', 'housein', '@job'),
(163, '2016-02-17 03:47:41', 2000000, 150003, 'Alan', 'housein', '@ccolor 1'),
(164, '2016-02-17 03:47:44', 2000000, 150003, 'Alan', 'housein', '@ccolor 0'),
(165, '2016-02-17 03:47:49', 2000000, 150003, 'Alan', 'housein', '@repairall'),
(166, '2016-02-17 03:47:49', 2000000, 150003, 'Alan', 'housein', '@speed 150'),
(167, '2016-02-17 03:47:49', 2000000, 150003, 'Alan', 'housein', '@undisguise'),
(168, '2016-02-17 03:48:32', 2000000, 150003, 'Alan', 'housein', '@item 19149'),
(169, '2016-02-17 03:48:48', 2000000, 150003, 'Alan', 'housein', '@item 822'),
(170, '2016-02-17 03:48:54', 2000000, 150003, 'Alan', 'housein', '@item 822'),
(171, '2016-02-17 03:55:39', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(172, '2016-02-17 03:55:52', 2000000, 150003, 'Alan', 'housein', '@warp palle'),
(173, '2016-02-17 03:55:54', 2000000, 150003, 'Alan', 'pallet', '@warp pallet'),
(174, '2016-02-17 03:55:58', 2000000, 150003, 'Alan', 'pallet', '@warp pallet'),
(175, '2016-02-17 03:55:59', 2000000, 150003, 'Alan', 'pallet', '@warp pallet'),
(176, '2016-02-17 03:56:00', 2000000, 150003, 'Alan', 'pallet', '@warp pallet'),
(177, '2016-02-17 03:56:01', 2000000, 150003, 'Alan', 'pallet', '@warp pallet'),
(178, '2016-02-17 03:56:02', 2000000, 150003, 'Alan', 'pallet', '@warp pallet'),
(179, '2016-02-17 03:56:04', 2000000, 150003, 'Alan', 'pallet', '@warp pallet'),
(180, '2016-02-17 03:56:05', 2000000, 150003, 'Alan', 'pallet', '@warp pallet'),
(181, '2016-02-17 03:56:28', 2000000, 150003, 'Alan', 'pallet', '@reloadscript'),
(182, '2016-02-17 03:56:31', 2000000, 150003, 'Alan', 'pallet', '@reloadscript'),
(183, '2016-02-17 03:56:36', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(184, '2016-02-17 03:56:38', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(185, '2016-02-17 03:56:40', 2000000, 150003, 'Alan', 'housein', '@reloadscript'),
(186, '2016-02-17 03:56:41', 2000000, 150003, 'Alan', 'housein', '@save'),
(187, '2016-02-17 03:57:13', 2000000, 150003, 'Alan', 'housein', '@repairall'),
(188, '2016-02-17 04:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(189, '2016-02-17 04:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(190, '2016-02-17 04:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(191, '2016-02-17 04:01:02', 2000000, 150003, 'Alan', 'rota1', '@item ultraball,100'),
(192, '2016-02-17 04:01:05', 2000000, 150003, 'Alan', 'rota1', '@item ultraball'),
(193, '2016-02-17 04:01:07', 2000000, 150003, 'Alan', 'rota1', '@item ultraball 100'),
(194, '2016-02-17 04:02:47', 2000000, 150003, 'Alan', 'rota1', '@item love ball'),
(195, '2016-02-17 04:02:52', 2000000, 150003, 'Alan', 'rota1', '@item loveball'),
(196, '2016-02-17 04:03:50', 2000000, 150003, 'Alan', 'rota1', '@item curaball'),
(197, '2016-02-17 04:03:52', 2000000, 150003, 'Alan', 'rota1', '@item curaball 100'),
(198, '2016-02-17 04:05:09', 2000000, 150003, 'Alan', 'rota1', '@RELOADSCRIPT'),
(199, '2016-02-17 04:05:33', 2000000, 150003, 'Alan', 'rota1', '@item Honorball'),
(200, '2016-02-17 04:06:25', 2000000, 150003, 'Alan', 'housein', '@repairall'),
(201, '2016-02-17 04:07:01', 2000000, 150003, 'Alan', 'rota1', '@speed 1'),
(202, '2016-02-17 04:07:09', 2000000, 150003, 'Alan', 'rota1', '@speed 1'),
(203, '2016-02-17 04:07:14', 2000000, 150003, 'Alan', 'rota1', '@speed 1'),
(204, '2016-02-17 04:08:59', 2000000, 150003, 'Alan', 'lavender', '@warp lavender'),
(205, '2016-02-17 04:09:04', 2000000, 150003, 'Alan', 'lavender', '@speed 1'),
(206, '2016-02-17 04:09:22', 2000000, 150003, 'Alan', 'rota12', '@monster 2598'),
(207, '2016-02-17 04:09:27', 2000000, 150003, 'Alan', 'rota12', '@monster 2616'),
(208, '2016-02-17 04:10:03', 2000000, 150003, 'Alan', 'rota12', '@goto'),
(209, '2016-02-17 04:10:07', 2000000, 150003, 'Alan', 'rota12', '@goto moltres'),
(210, '2016-02-17 04:10:12', 2000000, 150003, 'Alan', 'rota12', '@goto zapdo'),
(211, '2016-02-17 04:10:14', 2000000, 150003, 'Alan', 'rota12', '@goto zapdos'),
(212, '2016-02-17 04:10:36', 2000000, 150003, 'Alan', 'rota12', '@monster 2572'),
(213, '2016-02-17 04:10:52', 2000000, 150003, 'Alan', 'rota12', '@monster 2586'),
(214, '2016-02-17 04:12:38', 2000000, 150003, 'Alan', 'rota12', '@monster 2586'),
(215, '2016-02-17 04:13:07', 2000000, 150003, 'Alan', 'lavender', '@speed 1'),
(216, '2016-02-17 04:13:53', 2000000, 150003, 'Alan', 'rota10', '@speed 1'),
(217, '2016-02-17 04:13:59', 2000000, 150003, 'Alan', 'rota10', '@speed 1'),
(218, '2016-02-17 04:14:02', 2000000, 150003, 'Alan', 'rota10', '@goto zapdos'),
(219, '2016-02-17 04:14:06', 2000000, 150003, 'Alan', 'rota10', '@speed 1'),
(220, '2016-02-17 04:14:23', 2000000, 150003, 'Alan', 'rota10', '@item revive'),
(221, '2016-02-17 04:14:34', 2000000, 150003, 'Alan', 'rota10', '@repairall'),
(222, '2016-02-17 04:14:56', 2000000, 150003, 'Alan', 'rota10', '@item ultra potion'),
(223, '2016-02-17 04:15:00', 2000000, 150003, 'Alan', 'rota10', '@item ultra pot'),
(224, '2016-02-17 04:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(225, '2016-02-17 04:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(226, '2016-02-17 04:15:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(227, '2016-02-17 04:16:07', 2000000, 150003, 'Alan', 'rota10', '@item 19184'),
(228, '2016-02-17 04:16:09', 2000000, 150003, 'Alan', 'rota10', '@item 19184 100'),
(229, '2016-02-17 04:16:19', 2000000, 150003, 'Alan', 'rota10', '@repairall'),
(230, '2016-02-17 04:16:23', 2000000, 150003, 'Alan', 'rota10', '@speed 1'),
(231, '2016-02-17 04:17:21', 2000000, 150003, 'Alan', 'rota10', '@warp rota 4'),
(232, '2016-02-17 04:17:23', 2000000, 150003, 'Alan', 'rota7', '@warp rota7'),
(233, '2016-02-17 04:17:30', 2000000, 150003, 'Alan', 'rota1', '@warp rota1'),
(234, '2016-02-17 04:17:34', 2000000, 150003, 'Alan', 'rota11', '@warp rota11'),
(235, '2016-02-17 04:18:48', 2000000, 150003, 'Alan', 'viridian', '@warp viridian'),
(236, '2016-02-17 04:19:04', 2000000, 150003, 'Alan', 'cpmarkin1', '@save'),
(237, '2016-02-17 04:19:05', 2000000, 150003, 'Alan', 'cpmarkin1', '@repairall'),
(238, '2016-02-17 04:19:05', 2000000, 150003, 'Alan', 'cpmarkin1', '@speed 150'),
(239, '2016-02-17 04:19:05', 2000000, 150003, 'Alan', 'cpmarkin1', '@undisguise'),
(240, '2016-02-17 04:19:07', 2000000, 150003, 'Alan', 'cpmarkin1', '@save'),
(241, '2016-02-17 04:19:08', 2000000, 150003, 'Alan', 'cpmarkin1', '@repairall'),
(242, '2016-02-17 04:19:08', 2000000, 150003, 'Alan', 'cpmarkin1', '@speed 150'),
(243, '2016-02-17 04:19:08', 2000000, 150003, 'Alan', 'cpmarkin1', '@undisguise'),
(244, '2016-02-17 04:19:11', 2000000, 150003, 'Alan', 'cpmarkin1', '@save'),
(245, '2016-02-17 04:19:42', 2000000, 150003, 'Alan', 'p_track01', '@item prizebox'),
(246, '2016-02-17 04:19:46', 2000000, 150003, 'Alan', 'p_track01', '@item prize box'),
(247, '2016-02-17 04:19:50', 2000000, 150003, 'Alan', 'p_track01', '@item prize_box'),
(248, '2016-02-17 04:20:34', 2000000, 150003, 'Alan', 'p_track01', '@makehomun 2633'),
(249, '2016-02-17 04:20:41', 2000000, 150003, 'Alan', 'p_track01', '@item 690'),
(250, '2016-02-17 04:20:51', 2000000, 150003, 'Alan', 'p_track01', '@item fire_stone'),
(251, '2016-02-17 04:20:59', 2000000, 150003, 'Alan', 'p_track01', '@item water_stone'),
(252, '2016-02-17 20:22:45', 2000000, 150003, 'Alan', 'cpmarkin1', '@speed 1'),
(253, '2016-02-17 20:29:08', 2000000, 150003, 'Alan', 'viridian', '@item 19192'),
(254, '2016-02-17 20:30:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(255, '2016-02-17 20:30:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(256, '2016-02-17 20:30:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(257, '2016-02-17 20:30:48', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(258, '2016-02-17 20:30:48', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(259, '2016-02-17 20:30:48', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(260, '2016-02-17 20:32:25', 2000000, 150003, 'Alan', 'viridian', '@makehomun 2626'),
(261, '2016-02-17 20:32:28', 2000000, 150003, 'Alan', 'viridian', '@item 690'),
(262, '2016-02-17 20:32:35', 2000000, 150003, 'Alan', 'viridian', '@hlvl 99'),
(263, '2016-02-17 20:33:14', 2000000, 150003, 'Alan', 'viridian', '@hlvl 99'),
(264, '2016-02-17 20:33:18', 2000000, 150003, 'Alan', 'viridian', '@hlvl 100'),
(265, '2016-02-17 20:33:38', 2000000, 150003, 'Alan', 'viridian', '@monster'),
(266, '2016-02-17 20:33:43', 2000000, 150003, 'Alan', 'viridian', '@monster alakazam'),
(267, '2016-02-17 20:34:23', 2000000, 150003, 'Alan', 'viridian', '@zeny 100000000'),
(268, '2016-02-17 20:34:32', 2000000, 150003, 'Alan', 'viridian', '@speed 1'),
(269, '2016-02-17 20:35:16', 2000000, 150003, 'Alan', 'cpmarkin1', '@monster articuno'),
(270, '2016-02-17 20:35:36', 2000000, 150003, 'Alan', 'cpmarkin1', '@repairall'),
(271, '2016-02-17 20:35:37', 2000000, 150003, 'Alan', 'cpmarkin1', '@heal'),
(272, '2016-02-17 20:36:34', 2000000, 150003, 'Alan', 'viridian', '@heal poke'),
(273, '2016-02-17 20:36:36', 2000000, 150003, 'Alan', 'viridian', '@heal'),
(274, '2016-02-17 20:36:43', 2000000, 150003, 'Alan', 'viridian', '@heal poke'),
(275, '2016-02-17 20:37:40', 2000000, 150003, 'Alan', 'cpmarkin1', '@repairall'),
(276, '2016-02-17 20:37:42', 2000000, 150003, 'Alan', 'cpmarkin1', '@heal'),
(277, '2016-02-17 20:38:03', 2000000, 150003, 'Alan', 'viridian', '@makehomun 2650'),
(278, '2016-02-17 20:38:06', 2000000, 150003, 'Alan', 'viridian', '@item 690'),
(279, '2016-02-17 20:38:15', 2000000, 150003, 'Alan', 'viridian', '@hlvl 100'),
(280, '2016-02-17 20:39:16', 2000000, 150003, 'Alan', 'cpmarkin1', '@heal'),
(281, '2016-02-17 20:39:18', 2000000, 150003, 'Alan', 'cpmarkin1', '@save'),
(282, '2016-02-17 20:39:36', 2000000, 150003, 'Alan', 'cpmarkin1', '@repairall'),
(283, '2016-02-17 20:39:48', 2000000, 150003, 'Alan', 'viridian', '@repairall'),
(284, '2016-02-17 20:39:49', 2000000, 150003, 'Alan', 'viridian', '@heal'),
(285, '2016-02-17 20:45:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(286, '2016-02-17 20:45:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(287, '2016-02-17 20:45:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(288, '2016-02-17 20:56:08', 2000000, 150003, 'Alan', 'cpmarkin1', '@monster charizard'),
(289, '2016-02-17 20:58:00', 2000000, 150003, 'Alan', 'cpmarkin1', '@save'),
(290, '2016-02-17 20:58:01', 2000000, 150003, 'Alan', 'cpmarkin1', '@repairall'),
(291, '2016-02-17 20:58:01', 2000000, 150003, 'Alan', 'cpmarkin1', '@speed 150'),
(292, '2016-02-17 20:58:01', 2000000, 150003, 'Alan', 'cpmarkin1', '@undisguise'),
(293, '2016-02-17 21:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 hunt1'),
(294, '2016-02-17 21:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 cerubeach'),
(295, '2016-02-17 21:00:00', 0, 0, 'MapNormalize', '', '@killmonster2 rota6'),
(296, '2016-02-17 21:01:54', 2000000, 150003, 'Alan', 'cpmarkin1', '@ccolor 81'),
(297, '2016-02-17 21:02:00', 2000000, 150003, 'Alan', 'cpmarkin1', '@ccolor 85'),
(298, '2016-02-17 21:02:03', 2000000, 150003, 'Alan', 'cpmarkin1', '@speed 1'),
(299, '2016-02-17 21:02:29', 2000000, 150003, 'Alan', 'rota2', '@dex 32767'),
(300, '2016-02-17 21:02:35', 2000000, 150003, 'Alan', 'rota2', '@vit 32767'),
(301, '2016-02-17 21:02:39', 2000000, 150003, 'Alan', 'rota2', '@heal'),
(302, '2016-02-17 21:02:46', 2000000, 150003, 'Alan', 'rota2', '@speed 1'),
(303, '2016-02-17 21:03:52', 2000000, 150003, 'Alan', 'rota2', '@goto'),
(304, '2016-02-17 21:04:02', 2000000, 150003, 'Alan', 'rota2', '@jumpto charmander'),
(305, '2016-02-17 21:04:14', 2000000, 150003, 'Alan', 'rota2', '@speed 1'),
(306, '2016-02-17 21:12:03', 2000000, 150003, 'Alan', 'rota2', '@item fly'),
(307, '2016-02-17 21:12:07', 2000000, 150003, 'Alan', 'rota2', '@item hm_fly'),
(308, '2016-02-17 21:12:09', 2000000, 150003, 'Alan', 'rota2', '@item hm_fly'),
(309, '2016-02-17 21:12:27', 2000000, 150003, 'Alan', 'rota2', '@monster zapdos'),
(310, '2016-02-17 21:12:49', 2000000, 150003, 'Alan', 'cpmarkin1', '@dex 1'),
(311, '2016-02-17 21:12:52', 2000000, 150003, 'Alan', 'cpmarkin1', '@dex 50'),
(312, '2016-02-17 21:12:59', 2000000, 150003, 'Alan', 'cpmarkin1', '@dex -'),
(313, '2016-02-17 21:13:09', 2000000, 150003, 'Alan', 'cpmarkin1', '@dex - 32767'),
(314, '2016-02-17 21:13:14', 2000000, 150003, 'Alan', 'cpmarkin1', '@dex -32767'),
(315, '2016-02-17 21:13:22', 2000000, 150003, 'Alan', 'cpmarkin1', '@vit -32767'),
(316, '2016-02-17 21:13:29', 2000000, 150003, 'Alan', 'cpmarkin1', '@vit 32766'),
(317, '2016-02-17 21:13:35', 2000000, 150003, 'Alan', 'cpmarkin1', '@dex 32766'),
(318, '2016-02-17 21:13:44', 2000000, 150003, 'Alan', 'cpmarkin1', '@heal'),
(319, '2016-02-17 21:13:47', 2000000, 150003, 'Alan', 'cpmarkin1', '@refresh'),
(320, '2016-02-17 21:13:52', 2000000, 150003, 'Alan', 'cpmarkin1', '@speed 1'),
(321, '2016-02-17 21:14:03', 2000000, 150003, 'Alan', 'housein', '@warp housein 115 59'),
(322, '2016-02-18 18:05:15', 2000000, 150003, 'Alan', 'housein', '@repairall'),
(323, '2016-02-18 18:05:15', 2000000, 150003, 'Alan', 'housein', '@speed 150'),
(324, '2016-02-18 18:05:15', 2000000, 150003, 'Alan', 'housein', '@undisguise'),
(325, '2016-02-18 18:06:16', 2000000, 150003, 'Alan', 'housein', '@blvl 99'),
(326, '2016-02-18 18:06:20', 2000000, 150003, 'Alan', 'housein', '@refresh');

-- --------------------------------------------------------

--
-- Estrutura da tabela `branchlog`
--

CREATE TABLE `branchlog` (
  `branch_id` mediumint(9) UNSIGNED NOT NULL,
  `branch_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `account_id` int(11) NOT NULL DEFAULT '0',
  `char_id` int(11) NOT NULL DEFAULT '0',
  `char_name` varchar(25) NOT NULL DEFAULT '',
  `map` varchar(11) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `chatlog`
--

CREATE TABLE `chatlog` (
  `id` bigint(20) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` enum('O','W','P','G','M') NOT NULL DEFAULT 'O',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `src_charid` int(11) NOT NULL DEFAULT '0',
  `src_accountid` int(11) NOT NULL DEFAULT '0',
  `src_map` varchar(11) NOT NULL DEFAULT '',
  `src_map_x` smallint(4) NOT NULL DEFAULT '0',
  `src_map_y` smallint(4) NOT NULL DEFAULT '0',
  `dst_charname` varchar(25) NOT NULL DEFAULT '',
  `message` varchar(150) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `chatlog`
--

INSERT INTO `chatlog` (`id`, `time`, `type`, `type_id`, `src_charid`, `src_accountid`, `src_map`, `src_map_x`, `src_map_y`, `dst_charname`, `message`) VALUES
(1, '2016-02-17 03:01:47', 'O', 0, 150000, 2000000, 'pallet', 70, 36, '', ' @makehomun 2568'),
(2, '2016-02-17 04:05:31', 'O', 0, 150003, 2000000, 'rota1', 84, 349, '', 'Honorball'),
(3, '2016-02-17 04:08:55', 'O', 0, 150003, 2000000, 'rota1', 209, 353, '', '°°°°°°'),
(4, '2016-02-17 04:19:54', 'O', 0, 150003, 2000000, 'p_track01', 32, 41, '', '°'),
(5, '2016-02-17 20:35:09', 'O', 0, 150003, 2000000, 'cpmarkin1', 171, 129, '', 'e°°');

-- --------------------------------------------------------

--
-- Estrutura da tabela `loginlog`
--

CREATE TABLE `loginlog` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(100) NOT NULL DEFAULT '',
  `user` varchar(23) NOT NULL DEFAULT '',
  `rcode` tinyint(4) NOT NULL DEFAULT '0',
  `log` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `loginlog`
--

INSERT INTO `loginlog` (`time`, `ip`, `user`, `rcode`, `log`) VALUES
('2016-02-17 01:46:31', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 01:46:32', '127.0.0.1', 'ro2pk', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 01:47:08', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 01:49:35', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 02:11:24', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:11:25', '25.87.133.151', 'ro2pk', 100, 'charserver - PkRO Adventure@25.87.133.151:6121'),
('2016-02-17 02:11:58', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 02:17:06', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:17:07', '25.87.133.151', 'ro2pk', 100, 'charserver - PkRO Adventure@25.87.133.151:6121'),
('2016-02-17 02:20:56', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:20:57', '25.87.133.151', 'ro2pk', 100, 'charserver - PkRO Adventure@25.87.133.151:6121'),
('2016-02-17 02:23:21', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:23:22', '25.87.133.151', 'ro2pk', 100, 'charserver - PkRO Adventure@25.87.133.151:6121'),
('2016-02-17 02:32:52', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:32:53', '25.87.133.151', 'ro2pk', 100, 'charserver - PkRO Adventure@25.87.133.151:6121'),
('2016-02-17 02:33:39', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 02:46:17', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:46:18', '25.87.133.151', 'ro2pk', 100, 'charserver - PkRO Adventure@25.87.133.151:6121'),
('2016-02-17 02:46:35', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 02:51:35', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:51:36', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 02:51:46', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 02:53:10', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:53:11', '127.0.0.1', 'ro2pk', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 02:54:23', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 02:56:59', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:57:00', '127.0.0.1', 'ro2pk', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 02:58:10', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 02:58:11', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 02:58:27', '127.0.0.1', 'lobinhopk2_m', 0, 'Unregistered ID.'),
('2016-02-17 02:58:59', '127.0.0.1', 'lobinhopk', 0, 'Unregistered ID.'),
('2016-02-17 03:00:25', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:01:32', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:02:59', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 03:03:00', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 03:03:12', '127.0.0.1', 'lobinhopk', 1, 'Incorrect Password.'),
('2016-02-17 03:05:10', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:05:46', '127.0.0.1', 'lobinhopk2', 100, 'login ok'),
('2016-02-17 03:07:36', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:08:20', '127.0.0.1', 'lobinhopk2', 100, 'login ok'),
('2016-02-17 03:13:01', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 03:13:02', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 03:13:32', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:20:37', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:25:29', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:25:43', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:27:52', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:28:44', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:31:05', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 03:31:06', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 03:31:20', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:45:38', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 03:45:39', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 03:45:48', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:47:15', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 03:53:02', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 03:53:04', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 03:53:20', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 20:21:36', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 20:21:37', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 20:22:36', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 20:28:44', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 20:28:45', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 20:28:53', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 20:31:09', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-17 20:31:10', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-17 20:31:14', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 20:55:04', '127.0.0.1', 'lobinhopk', 1, 'Incorrect Password.'),
('2016-02-17 20:55:08', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-17 21:14:47', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-18 16:10:19', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-18 16:10:21', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-18 18:04:55', '0.0.0.0', 'login server', 100, 'login server started'),
('2016-02-18 18:04:57', '127.0.0.1', 's1', 100, 'charserver - PkRO Adventure@127.0.0.1:6121'),
('2016-02-18 18:05:04', '127.0.0.1', 'lobinhopk', 100, 'login ok'),
('2016-02-18 18:06:49', '127.0.0.1', 'lobinhopk', 100, 'login ok');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mvplog`
--

CREATE TABLE `mvplog` (
  `mvp_id` mediumint(9) UNSIGNED NOT NULL,
  `mvp_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `kill_char_id` int(11) NOT NULL DEFAULT '0',
  `monster_id` smallint(6) NOT NULL DEFAULT '0',
  `prize` int(11) NOT NULL DEFAULT '0',
  `mvpexp` mediumint(9) NOT NULL DEFAULT '0',
  `map` varchar(11) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `npclog`
--

CREATE TABLE `npclog` (
  `npc_id` mediumint(9) UNSIGNED NOT NULL,
  `npc_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `account_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `char_name` varchar(25) NOT NULL DEFAULT '',
  `map` varchar(11) NOT NULL DEFAULT '',
  `mes` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `picklog`
--

CREATE TABLE `picklog` (
  `id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `char_id` int(11) NOT NULL DEFAULT '0',
  `type` enum('M','P','L','T','V','S','N','C','A','R','G','E','B') NOT NULL DEFAULT 'P',
  `nameid` int(11) NOT NULL DEFAULT '0',
  `amount` int(11) NOT NULL DEFAULT '1',
  `refine` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `card0` int(11) NOT NULL DEFAULT '0',
  `card1` int(11) NOT NULL DEFAULT '0',
  `card2` int(11) NOT NULL DEFAULT '0',
  `card3` int(11) NOT NULL DEFAULT '0',
  `map` varchar(11) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `picklog`
--

INSERT INTO `picklog` (`id`, `time`, `char_id`, `type`, `nameid`, `amount`, `refine`, `card0`, `card1`, `card2`, `card3`, `map`) VALUES
(1, '2016-02-17 01:47:48', 150000, 'N', 19149, 25, 0, 0, 0, 0, 0, 'housein'),
(2, '2016-02-17 01:47:48', 150000, 'N', 18002, 1, 0, 0, 0, 0, 0, 'housein'),
(3, '2016-02-17 01:47:48', 150000, 'N', 690, 1, 0, 0, 0, 0, 0, 'housein');

-- --------------------------------------------------------

--
-- Estrutura da tabela `zenylog`
--

CREATE TABLE `zenylog` (
  `id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `char_id` int(11) NOT NULL DEFAULT '0',
  `src_id` int(11) NOT NULL DEFAULT '0',
  `type` enum('M','T','V','S','N','A','E','B') NOT NULL DEFAULT 'S',
  `amount` int(11) NOT NULL DEFAULT '0',
  `map` varchar(11) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `zenylog`
--

INSERT INTO `zenylog` (`id`, `time`, `char_id`, `src_id`, `type`, `amount`, `map`) VALUES
(1, '2016-02-17 03:55:45', 150003, 150003, 'S', 125, 'housein'),
(2, '2016-02-17 20:34:54', 150003, 150003, 'S', -850000, 'cpmarkin1'),
(3, '2016-02-17 20:40:27', 150003, 150003, 'S', 9000, 'cpmarkin1'),
(4, '2016-02-17 20:56:34', 150003, 150003, 'S', 100, 'cpmarkin1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `atcommandlog`
--
ALTER TABLE `atcommandlog`
  ADD PRIMARY KEY (`atcommand_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `branchlog`
--
ALTER TABLE `branchlog`
  ADD PRIMARY KEY (`branch_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `chatlog`
--
ALTER TABLE `chatlog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `src_accountid` (`src_accountid`),
  ADD KEY `src_charid` (`src_charid`);

--
-- Indexes for table `loginlog`
--
ALTER TABLE `loginlog`
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `mvplog`
--
ALTER TABLE `mvplog`
  ADD PRIMARY KEY (`mvp_id`);

--
-- Indexes for table `npclog`
--
ALTER TABLE `npclog`
  ADD PRIMARY KEY (`npc_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `picklog`
--
ALTER TABLE `picklog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `zenylog`
--
ALTER TABLE `zenylog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `atcommandlog`
--
ALTER TABLE `atcommandlog`
  MODIFY `atcommand_id` mediumint(9) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=327;
--
-- AUTO_INCREMENT for table `branchlog`
--
ALTER TABLE `branchlog`
  MODIFY `branch_id` mediumint(9) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `chatlog`
--
ALTER TABLE `chatlog`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `mvplog`
--
ALTER TABLE `mvplog`
  MODIFY `mvp_id` mediumint(9) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `npclog`
--
ALTER TABLE `npclog`
  MODIFY `npc_id` mediumint(9) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `picklog`
--
ALTER TABLE `picklog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zenylog`
--
ALTER TABLE `zenylog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

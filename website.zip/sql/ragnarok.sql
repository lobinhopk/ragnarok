-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 24-Fev-2016 às 02:18
-- Versão do servidor: 5.7.11
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ragnarok`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `auction`
--

CREATE TABLE `auction` (
  `auction_id` bigint(20) UNSIGNED NOT NULL,
  `seller_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `seller_name` varchar(30) NOT NULL DEFAULT '',
  `buyer_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `buyer_name` varchar(30) NOT NULL DEFAULT '',
  `price` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `buynow` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hours` smallint(6) NOT NULL DEFAULT '0',
  `timestamp` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `nameid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `item_name` varchar(50) NOT NULL DEFAULT '',
  `type` smallint(6) NOT NULL DEFAULT '0',
  `refine` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `attribute` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `card0` smallint(11) NOT NULL DEFAULT '0',
  `card1` smallint(11) NOT NULL DEFAULT '0',
  `card2` smallint(11) NOT NULL DEFAULT '0',
  `card3` smallint(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cart_inventory`
--

CREATE TABLE `cart_inventory` (
  `id` int(11) NOT NULL,
  `char_id` int(11) NOT NULL DEFAULT '0',
  `nameid` int(11) NOT NULL DEFAULT '0',
  `amount` int(11) NOT NULL DEFAULT '0',
  `equip` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `identify` smallint(6) NOT NULL DEFAULT '0',
  `refine` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `attribute` tinyint(4) NOT NULL DEFAULT '0',
  `card0` smallint(11) NOT NULL DEFAULT '0',
  `card1` smallint(11) NOT NULL DEFAULT '0',
  `card2` smallint(11) NOT NULL DEFAULT '0',
  `card3` smallint(11) NOT NULL DEFAULT '0',
  `expire_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `char`
--

CREATE TABLE `char` (
  `char_id` int(11) UNSIGNED NOT NULL,
  `account_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `char_num` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(30) NOT NULL DEFAULT '',
  `class` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `base_level` smallint(6) UNSIGNED NOT NULL DEFAULT '1',
  `job_level` smallint(6) UNSIGNED NOT NULL DEFAULT '1',
  `base_exp` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `job_exp` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `zeny` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `str` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `agi` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `vit` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `int` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `dex` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `luk` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `max_hp` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hp` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `max_sp` mediumint(6) UNSIGNED NOT NULL DEFAULT '0',
  `sp` mediumint(6) UNSIGNED NOT NULL DEFAULT '0',
  `status_point` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `skill_point` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `option` int(11) NOT NULL DEFAULT '0',
  `karma` tinyint(3) NOT NULL DEFAULT '0',
  `manner` smallint(6) NOT NULL DEFAULT '0',
  `party_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `guild_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `pet_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `homun_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hair` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `hair_color` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `clothes_color` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `weapon` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `shield` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `head_top` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `head_mid` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `head_bottom` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `robe` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `last_map` varchar(11) NOT NULL DEFAULT '',
  `last_x` smallint(4) UNSIGNED NOT NULL DEFAULT '53',
  `last_y` smallint(4) UNSIGNED NOT NULL DEFAULT '111',
  `save_map` varchar(11) NOT NULL DEFAULT '',
  `save_x` smallint(4) UNSIGNED NOT NULL DEFAULT '53',
  `save_y` smallint(4) UNSIGNED NOT NULL DEFAULT '111',
  `partner_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `online` tinyint(2) NOT NULL DEFAULT '0',
  `father` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `mother` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `child` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `fame` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `rename` smallint(3) UNSIGNED NOT NULL DEFAULT '0',
  `delete_date` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `char`
--

INSERT INTO `char` (`char_id`, `account_id`, `char_num`, `name`, `class`, `base_level`, `job_level`, `base_exp`, `job_exp`, `zeny`, `str`, `agi`, `vit`, `int`, `dex`, `luk`, `max_hp`, `hp`, `max_sp`, `sp`, `status_point`, `skill_point`, `option`, `karma`, `manner`, `party_id`, `guild_id`, `pet_id`, `homun_id`, `hair`, `hair_color`, `clothes_color`, `weapon`, `shield`, `head_top`, `head_mid`, `head_bottom`, `robe`, `last_map`, `last_x`, `last_y`, `save_map`, `save_x`, `save_y`, `partner_id`, `online`, `father`, `mother`, `child`, `fame`, `rename`, `delete_date`) VALUES
(150003, 2000000, 0, 'Alan', 0, 42, 6, 1463, 20, 99159225, 5, 5, 32767, 5, 32767, 5, 1638850, 1000000, 54, 54, 0, 2, 0, 0, 0, 0, 0, 0, 0, 33, 9, 85, 0, 1, 812, 856, 815, 0, 'housein', 115, 59, 'cpmarkin1', 107, 65, 0, 0, 0, 0, 0, 0, 0, 0),
(150001, 2000001, 0, 'Alann', 0, 1, 1, 0, 0, 0, 5, 5, 5, 5, 5, 5, 750, 272, 11, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 857, 0, 0, 0, 0, 0, 'housein', 66, 95, 'housein', 67, 121, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `charlog`
--

CREATE TABLE `charlog` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `char_msg` varchar(255) NOT NULL DEFAULT 'char select',
  `account_id` int(11) NOT NULL DEFAULT '0',
  `char_num` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(23) NOT NULL DEFAULT '',
  `str` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `agi` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `vit` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `int` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `dex` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `luk` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hair` tinyint(4) NOT NULL DEFAULT '0',
  `hair_color` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `charlog`
--

INSERT INTO `charlog` (`time`, `char_msg`, `account_id`, `char_num`, `name`, `str`, `agi`, `vit`, `int`, `dex`, `luk`, `hair`, `hair_color`) VALUES
('2016-02-17 03:00:28', 'make new char', 2000000, 0, 'Alan', 5, 5, 5, 5, 5, 5, 1, 0),
('2016-02-17 03:00:28', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:01:33', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:05:12', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:05:50', 'make new char', 2000001, 0, 'Alann', 5, 5, 5, 5, 5, 5, 1, 0),
('2016-02-17 03:05:50', 'char select', 2000001, 0, 'Alann', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:07:38', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:08:21', 'char select', 2000001, 0, 'Alann', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:13:33', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:20:38', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:23:02', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:23:21', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:25:45', 'make new char', 2000000, 0, 'Alan', 5, 5, 5, 5, 5, 5, 1, 0),
('2016-02-17 03:25:46', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:27:52', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:28:47', 'make new char', 2000000, 0, 'Alan', 5, 5, 5, 5, 5, 5, 1, 0),
('2016-02-17 03:28:47', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:31:21', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:36:16', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:45:49', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:47:16', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 03:53:21', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 20:22:37', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 20:28:54', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 20:30:25', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 20:31:15', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 20:55:09', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-17 21:14:48', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-18 18:05:05', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0),
('2016-02-18 18:06:50', 'char select', 2000000, 0, 'Alan', 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `donationx`
--

CREATE TABLE `donationx` (
  `time` varchar(12) NOT NULL,
  `accid` int(11) NOT NULL,
  `cashpoints` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `friends`
--

CREATE TABLE `friends` (
  `char_id` int(11) NOT NULL DEFAULT '0',
  `friend_account` int(11) NOT NULL DEFAULT '0',
  `friend_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `global_reg_value`
--

CREATE TABLE `global_reg_value` (
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `str` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '3',
  `account_id` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `global_reg_value`
--

INSERT INTO `global_reg_value` (`char_id`, `str`, `value`, `type`, `account_id`) VALUES
(150001, 'oak', '1', 3, 0),
(0, '#CASHPOINTS', '15000', 2, 2000000),
(150000, 'oak', '1', 3, 0),
(150000, 'jobchange_level', '1', 3, 0),
(150002, 'jobchange_level', '1', 3, 0),
(150003, 'rod1', '1', 3, 0),
(150003, 'PC_DIE_COUNTER', '8', 3, 0),
(150003, 'oak', '1', 3, 0),
(150003, 'npc1', '1', 3, 0),
(150003, 'city1', '1', 3, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild`
--

CREATE TABLE `guild` (
  `guild_id` int(11) UNSIGNED NOT NULL,
  `name` varchar(24) NOT NULL DEFAULT '',
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `master` varchar(24) NOT NULL DEFAULT '',
  `guild_lv` tinyint(6) UNSIGNED NOT NULL DEFAULT '0',
  `connect_member` tinyint(6) UNSIGNED NOT NULL DEFAULT '0',
  `max_member` tinyint(6) UNSIGNED NOT NULL DEFAULT '0',
  `average_lv` smallint(6) UNSIGNED NOT NULL DEFAULT '1',
  `exp` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `next_exp` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `skill_point` tinyint(11) UNSIGNED NOT NULL DEFAULT '0',
  `mes1` varchar(60) NOT NULL DEFAULT '',
  `mes2` varchar(120) NOT NULL DEFAULT '',
  `emblem_len` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `emblem_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `emblem_data` blob
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_alliance`
--

CREATE TABLE `guild_alliance` (
  `guild_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `opposition` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `alliance_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_castle`
--

CREATE TABLE `guild_castle` (
  `castle_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `guild_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `economy` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `defense` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `triggerE` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `triggerD` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `nextTime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `payTime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `createTime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleC` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleG0` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleG1` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleG2` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleG3` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleG4` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleG5` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleG6` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `visibleG7` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_expulsion`
--

CREATE TABLE `guild_expulsion` (
  `guild_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `account_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT '',
  `mes` varchar(40) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_member`
--

CREATE TABLE `guild_member` (
  `guild_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `account_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hair` tinyint(6) UNSIGNED NOT NULL DEFAULT '0',
  `hair_color` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `gender` tinyint(6) UNSIGNED NOT NULL DEFAULT '0',
  `class` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `lv` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `exp` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `exp_payper` tinyint(11) UNSIGNED NOT NULL DEFAULT '0',
  `online` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `position` tinyint(6) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_position`
--

CREATE TABLE `guild_position` (
  `guild_id` int(9) UNSIGNED NOT NULL DEFAULT '0',
  `position` tinyint(6) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT '',
  `mode` tinyint(11) UNSIGNED NOT NULL DEFAULT '0',
  `exp_mode` tinyint(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_skill`
--

CREATE TABLE `guild_skill` (
  `guild_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `id` smallint(11) UNSIGNED NOT NULL DEFAULT '0',
  `lv` tinyint(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `guild_storage`
--

CREATE TABLE `guild_storage` (
  `id` int(10) UNSIGNED NOT NULL,
  `guild_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `nameid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `amount` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `equip` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `identify` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `refine` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `attribute` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `card0` smallint(11) NOT NULL DEFAULT '0',
  `card1` smallint(11) NOT NULL DEFAULT '0',
  `card2` smallint(11) NOT NULL DEFAULT '0',
  `card3` smallint(11) NOT NULL DEFAULT '0',
  `expire_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `homunculus`
--

CREATE TABLE `homunculus` (
  `homun_id` int(11) NOT NULL,
  `char_id` int(11) NOT NULL,
  `class` mediumint(9) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT '',
  `level` smallint(4) NOT NULL DEFAULT '0',
  `exp` int(12) NOT NULL DEFAULT '0',
  `intimacy` int(12) NOT NULL DEFAULT '0',
  `hunger` smallint(4) NOT NULL DEFAULT '0',
  `str` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `agi` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `vit` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `int` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `dex` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `luk` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `hp` int(12) NOT NULL DEFAULT '1',
  `max_hp` int(12) NOT NULL DEFAULT '1',
  `sp` int(12) NOT NULL DEFAULT '1',
  `max_sp` int(12) NOT NULL DEFAULT '1',
  `skill_point` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `alive` tinyint(2) NOT NULL DEFAULT '1',
  `rename_flag` tinyint(2) NOT NULL DEFAULT '0',
  `vaporize` tinyint(2) NOT NULL DEFAULT '0',
  `lvlevo1` smallint(3) NOT NULL,
  `lvlevo2` smallint(3) NOT NULL,
  `resto_str` smallint(3) NOT NULL,
  `resto_agi` smallint(3) NOT NULL,
  `resto_vit` smallint(3) NOT NULL,
  `resto_dex` smallint(3) NOT NULL,
  `resto_int_` smallint(3) NOT NULL,
  `resto_luk` smallint(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `homunculus`
--

INSERT INTO `homunculus` (`homun_id`, `char_id`, `class`, `name`, `level`, `exp`, `intimacy`, `hunger`, `str`, `agi`, `vit`, `int`, `dex`, `luk`, `hp`, `max_hp`, `sp`, `max_sp`, `skill_point`, `alive`, `rename_flag`, `vaporize`, `lvlevo1`, `lvlevo2`, `resto_str`, `resto_agi`, `resto_vit`, `resto_dex`, `resto_int_`, `resto_luk`) VALUES
(1, 150000, 2510, 'Caterpie', 1, 0, 1000, 32, 50, 50, 50, 50, 50, 10, 22, 300, 6, 100, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 150000, 2516, 'Pidgey', 1, 0, 1000, 32, 50, 50, 50, 50, 50, 10, 22, 300, 6, 100, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 150003, 2518, 'Pidgeot', 40, 835, 200, 93, 440, 430, 480, 520, 530, 190, 2707, 2707, 295, 295, 0, 1, 1, 0, 18, 36, 9, 6, 5, 5, 3, 3),
(4, 150003, 2633, 'Eevee', 1, 0, 1000, 32, 50, 50, 50, 50, 50, 10, 300, 300, 100, 100, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 150003, 2626, 'Magmar', 99, 0, 1000, 27, 1060, 1060, 1110, 2020, 1310, 480, 16425, 16425, 590, 590, 0, 1, 0, 0, 0, 0, 0, 4, 5, 4, 4, 8),
(6, 150003, 2650, 'Mewtwo', 99, 0, 1000, 16, 2510, 1490, 4480, 7180, 2920, 1510, 44218, 44218, 590, 590, 0, 1, 0, 0, 0, 0, 4, 7, 5, 7, 0, 7);

-- --------------------------------------------------------

--
-- Estrutura da tabela `hotkey`
--

CREATE TABLE `hotkey` (
  `char_id` int(11) NOT NULL,
  `hotkey` tinyint(2) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `itemskill_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `skill_lvl` tinyint(4) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `hotkey`
--

INSERT INTO `hotkey` (`char_id`, `hotkey`, `type`, `itemskill_id`, `skill_lvl`) VALUES
(150003, 0, 1, 8024, 10),
(150003, 1, 1, 8026, 10),
(150003, 2, 1, 8027, 10),
(150003, 3, 1, 8029, 10),
(150003, 8, 0, 19081, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `interlog`
--

CREATE TABLE `interlog` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) UNSIGNED NOT NULL,
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `nameid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `amount` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `equip` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `identify` smallint(6) NOT NULL DEFAULT '0',
  `refine` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `attribute` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `card0` smallint(11) NOT NULL DEFAULT '0',
  `card1` smallint(11) NOT NULL DEFAULT '0',
  `card2` smallint(11) NOT NULL DEFAULT '0',
  `card3` smallint(11) NOT NULL DEFAULT '0',
  `expire_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `inventory`
--

INSERT INTO `inventory` (`id`, `char_id`, `nameid`, `amount`, `equip`, `identify`, `refine`, `attribute`, `card0`, `card1`, `card2`, `card3`, `expire_time`) VALUES
(44, 150003, 8180, 1, 0, 1, 0, 0, -256, 6, 0, 0, 0),
(35, 150003, 19081, 86, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(41, 150003, 8156, 1, 0, 1, 0, 0, -256, 5, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `ipbanlist`
--

CREATE TABLE `ipbanlist` (
  `list` varchar(255) NOT NULL DEFAULT '',
  `btime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reason` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

CREATE TABLE `login` (
  `account_id` int(11) UNSIGNED NOT NULL,
  `userid` varchar(23) NOT NULL DEFAULT '',
  `user_pass` varchar(32) NOT NULL DEFAULT '',
  `sex` enum('M','F','S') NOT NULL DEFAULT 'M',
  `email` varchar(39) NOT NULL DEFAULT '',
  `level` tinyint(3) NOT NULL DEFAULT '0',
  `state` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `unban_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `expiration_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `logincount` mediumint(9) UNSIGNED NOT NULL DEFAULT '0',
  `lastlogin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(100) NOT NULL DEFAULT '',
  `birthdate` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login` (`account_id`, `userid`, `user_pass`, `sex`, `email`, `level`, `state`, `unban_time`, `expiration_time`, `logincount`, `lastlogin`, `last_ip`, `birthdate`) VALUES
(1, 's1', 'p1', 'S', 'athena@athena.com', 0, 0, 0, 0, 11, '2016-02-18 18:04:57', '127.0.0.1', '0000-00-00'),
(2000000, 'lobinhopk', 'Aa.26843611', 'M', 'lobinho.titans@hotmail.com', 99, 0, 0, 0, 21, '2016-02-18 18:06:49', '127.0.0.1', '1999-01-10'),
(2000001, 'lobinhopk2', '26843611', 'M', 'a@a.com', 0, 0, 0, 0, 2, '2016-02-17 03:08:20', '127.0.0.1', '0000-00-00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mail`
--

CREATE TABLE `mail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `send_name` varchar(30) NOT NULL DEFAULT '',
  `send_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `dest_name` varchar(30) NOT NULL DEFAULT '',
  `dest_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(45) NOT NULL DEFAULT '',
  `message` varchar(255) NOT NULL DEFAULT '',
  `time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `zeny` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `nameid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `amount` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `refine` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `attribute` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `identify` smallint(6) NOT NULL DEFAULT '0',
  `card0` smallint(11) NOT NULL DEFAULT '0',
  `card1` smallint(11) NOT NULL DEFAULT '0',
  `card2` smallint(11) NOT NULL DEFAULT '0',
  `card3` smallint(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mapreg`
--

CREATE TABLE `mapreg` (
  `varname` varchar(32) NOT NULL,
  `index` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `mapreg`
--

INSERT INTO `mapreg` (`varname`, `index`, `value`) VALUES
('$prace_random', 0, '70'),
('$prace_random2', 0, '600'),
('$dona', 0, '1000'),
('$value', 0, '333'),
('$nomec$', 0, 'Cash'),
('$lvlgm', 0, '99'),
('$bdias$', 0, 'diasvip'),
('$lvl', 0, '1'),
('$lvlfree', 0, '1'),
('$npc1$', 0, '[^0000FFVendedor VIP^000000]'),
('$npc$', 0, '[^0000FFAdicionar dias VIP^000000]'),
('$prace_gate', 0, '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `memo`
--

CREATE TABLE `memo` (
  `memo_id` int(11) UNSIGNED NOT NULL,
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `map` varchar(11) NOT NULL DEFAULT '',
  `x` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `y` smallint(4) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mercenary`
--

CREATE TABLE `mercenary` (
  `mer_id` int(11) UNSIGNED NOT NULL,
  `char_id` int(11) NOT NULL,
  `class` mediumint(9) UNSIGNED NOT NULL DEFAULT '0',
  `hp` int(12) NOT NULL DEFAULT '1',
  `sp` int(12) NOT NULL DEFAULT '1',
  `kill_counter` int(11) NOT NULL,
  `life_time` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mercenary_owner`
--

CREATE TABLE `mercenary_owner` (
  `char_id` int(11) NOT NULL,
  `merc_id` int(11) NOT NULL DEFAULT '0',
  `arch_calls` int(11) NOT NULL DEFAULT '0',
  `arch_faith` int(11) NOT NULL DEFAULT '0',
  `spear_calls` int(11) NOT NULL DEFAULT '0',
  `spear_faith` int(11) NOT NULL DEFAULT '0',
  `sword_calls` int(11) NOT NULL DEFAULT '0',
  `sword_faith` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `npc_pvpsys`
--

CREATE TABLE `npc_pvpsys` (
  `char_id` int(11) NOT NULL,
  `pvp_kills` int(11) NOT NULL,
  `pvp_deaths` int(11) NOT NULL,
  `char_name` varchar(20) NOT NULL,
  `streak` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `party`
--

CREATE TABLE `party` (
  `party_id` int(11) UNSIGNED NOT NULL,
  `name` varchar(24) NOT NULL DEFAULT '',
  `exp` tinyint(11) UNSIGNED NOT NULL DEFAULT '0',
  `item` tinyint(11) UNSIGNED NOT NULL DEFAULT '0',
  `leader_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `leader_char` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pet`
--

CREATE TABLE `pet` (
  `pet_id` int(11) UNSIGNED NOT NULL,
  `class` mediumint(9) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT '',
  `account_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `level` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `egg_id` smallint(11) UNSIGNED NOT NULL DEFAULT '0',
  `equip` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `intimate` smallint(9) UNSIGNED NOT NULL DEFAULT '0',
  `hungry` smallint(9) UNSIGNED NOT NULL DEFAULT '0',
  `rename_flag` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `incuvate` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `quest`
--

CREATE TABLE `quest` (
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `quest_id` int(10) UNSIGNED NOT NULL,
  `state` enum('0','1','2') NOT NULL DEFAULT '0',
  `time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `count1` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `count2` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `count3` mediumint(8) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ragsrvinfo`
--

CREATE TABLE `ragsrvinfo` (
  `index` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `exp` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `jexp` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `drop` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `ragsrvinfo`
--

INSERT INTO `ragsrvinfo` (`index`, `name`, `exp`, `jexp`, `drop`) VALUES
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100),
(3, 'PkRO Adventure', 1000, 1000, 100);

-- --------------------------------------------------------

--
-- Estrutura da tabela `registration`
--

CREATE TABLE `registration` (
  `userid` varchar(23) NOT NULL DEFAULT '',
  `user_pass` varchar(32) NOT NULL DEFAULT '',
  `sex` enum('M','F','S') NOT NULL DEFAULT 'M',
  `email` varchar(39) NOT NULL DEFAULT '',
  `last_ip` varchar(100) NOT NULL DEFAULT '',
  `code` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sc_data`
--

CREATE TABLE `sc_data` (
  `account_id` int(11) UNSIGNED NOT NULL,
  `char_id` int(11) UNSIGNED NOT NULL,
  `type` smallint(11) UNSIGNED NOT NULL,
  `tick` int(11) NOT NULL,
  `val1` int(11) NOT NULL DEFAULT '0',
  `val2` int(11) NOT NULL DEFAULT '0',
  `val3` int(11) NOT NULL DEFAULT '0',
  `val4` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `skill`
--

CREATE TABLE `skill` (
  `char_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `id` smallint(11) UNSIGNED NOT NULL DEFAULT '0',
  `lv` tinyint(4) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `skill`
--

INSERT INTO `skill` (`char_id`, `id`, `lv`) VALUES
(150000, 2, 10),
(150000, 4, 10),
(150000, 5, 10),
(150000, 6, 10),
(150001, 36, 0),
(150001, 9, 0),
(150001, 4, 0),
(150001, 1, 0),
(150001, 244, 1),
(150000, 1, 9),
(150000, 7, 10),
(150000, 8, 10),
(150000, 9, 10),
(150000, 10, 1),
(150000, 11, 10),
(150000, 12, 10),
(150000, 13, 10),
(150000, 14, 10),
(150000, 15, 10),
(150000, 16, 10),
(150000, 17, 10),
(150000, 18, 10),
(150000, 19, 10),
(150000, 20, 10),
(150000, 21, 10),
(150000, 22, 10),
(150000, 23, 10),
(150000, 24, 1),
(150000, 25, 1),
(150000, 26, 2),
(150000, 27, 4),
(150000, 28, 10),
(150000, 29, 10),
(150000, 30, 10),
(150000, 31, 1),
(150000, 32, 10),
(150000, 33, 10),
(150000, 34, 10),
(150000, 35, 1),
(150000, 36, 10),
(150000, 37, 10),
(150000, 38, 10),
(150000, 39, 10),
(150000, 40, 1),
(150000, 41, 10),
(150000, 42, 10),
(150000, 43, 10),
(150000, 44, 10),
(150000, 45, 10),
(150000, 48, 10),
(150000, 49, 10),
(150000, 50, 10),
(150000, 51, 10),
(150000, 52, 10),
(150000, 53, 1),
(150000, 142, 1),
(150000, 244, 1),
(150000, 408, 1),
(150000, 409, 1),
(150000, 681, 1),
(150000, 2535, 1),
(150002, 1, 0),
(150002, 142, 0),
(150002, 143, 0),
(150002, 408, 0),
(150002, 409, 0),
(150002, 681, 0),
(150003, 36, 0),
(150003, 244, 1),
(150003, 1, 3),
(150003, 9, 0),
(150003, 4, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `skill_homunculus`
--

CREATE TABLE `skill_homunculus` (
  `homun_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `lv` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `skill_homunculus`
--

INSERT INTO `skill_homunculus` (`homun_id`, `id`, `lv`) VALUES
(1, 8040, 5),
(2, 8040, 5),
(3, 8040, 10),
(3, 8020, 10),
(3, 8030, 10),
(3, 8032, 10),
(3, 8021, 10),
(4, 8040, 5),
(5, 8040, 10),
(5, 8001, 10),
(5, 8004, 10),
(5, 8016, 10),
(5, 8039, 10),
(6, 8024, 10),
(6, 8010, 10),
(6, 8026, 10),
(6, 8027, 10),
(6, 8029, 10),
(6, 8032, 10),
(6, 8033, 10);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sstatus`
--

CREATE TABLE `sstatus` (
  `index` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `user` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `storage`
--

CREATE TABLE `storage` (
  `id` int(11) UNSIGNED NOT NULL,
  `account_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `nameid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `amount` smallint(11) UNSIGNED NOT NULL DEFAULT '0',
  `equip` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `identify` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `refine` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `attribute` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `card0` smallint(11) NOT NULL DEFAULT '0',
  `card1` smallint(11) NOT NULL DEFAULT '0',
  `card2` smallint(11) NOT NULL DEFAULT '0',
  `card3` smallint(11) NOT NULL DEFAULT '0',
  `expire_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auction`
--
ALTER TABLE `auction`
  ADD PRIMARY KEY (`auction_id`);

--
-- Indexes for table `cart_inventory`
--
ALTER TABLE `cart_inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `char`
--
ALTER TABLE `char`
  ADD PRIMARY KEY (`char_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `party_id` (`party_id`),
  ADD KEY `guild_id` (`guild_id`),
  ADD KEY `name` (`name`),
  ADD KEY `online` (`online`);

--
-- Indexes for table `donationx`
--
ALTER TABLE `donationx`
  ADD PRIMARY KEY (`accid`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `global_reg_value`
--
ALTER TABLE `global_reg_value`
  ADD PRIMARY KEY (`char_id`,`str`,`account_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `guild`
--
ALTER TABLE `guild`
  ADD PRIMARY KEY (`guild_id`,`char_id`),
  ADD UNIQUE KEY `guild_id` (`guild_id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `guild_alliance`
--
ALTER TABLE `guild_alliance`
  ADD PRIMARY KEY (`guild_id`,`alliance_id`),
  ADD KEY `alliance_id` (`alliance_id`);

--
-- Indexes for table `guild_castle`
--
ALTER TABLE `guild_castle`
  ADD PRIMARY KEY (`castle_id`),
  ADD KEY `guild_id` (`guild_id`);

--
-- Indexes for table `guild_expulsion`
--
ALTER TABLE `guild_expulsion`
  ADD PRIMARY KEY (`guild_id`,`name`);

--
-- Indexes for table `guild_member`
--
ALTER TABLE `guild_member`
  ADD PRIMARY KEY (`guild_id`,`char_id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `guild_position`
--
ALTER TABLE `guild_position`
  ADD PRIMARY KEY (`guild_id`,`position`),
  ADD KEY `guild_id` (`guild_id`);

--
-- Indexes for table `guild_skill`
--
ALTER TABLE `guild_skill`
  ADD PRIMARY KEY (`guild_id`,`id`);

--
-- Indexes for table `guild_storage`
--
ALTER TABLE `guild_storage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `guild_id` (`guild_id`);

--
-- Indexes for table `homunculus`
--
ALTER TABLE `homunculus`
  ADD PRIMARY KEY (`homun_id`);

--
-- Indexes for table `hotkey`
--
ALTER TABLE `hotkey`
  ADD PRIMARY KEY (`char_id`,`hotkey`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `ipbanlist`
--
ALTER TABLE `ipbanlist`
  ADD KEY `list` (`list`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`account_id`),
  ADD KEY `name` (`userid`);

--
-- Indexes for table `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mapreg`
--
ALTER TABLE `mapreg`
  ADD KEY `varname` (`varname`),
  ADD KEY `index` (`index`);

--
-- Indexes for table `memo`
--
ALTER TABLE `memo`
  ADD PRIMARY KEY (`memo_id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `mercenary`
--
ALTER TABLE `mercenary`
  ADD PRIMARY KEY (`mer_id`);

--
-- Indexes for table `mercenary_owner`
--
ALTER TABLE `mercenary_owner`
  ADD PRIMARY KEY (`char_id`);

--
-- Indexes for table `npc_pvpsys`
--
ALTER TABLE `npc_pvpsys`
  ADD PRIMARY KEY (`char_id`);

--
-- Indexes for table `party`
--
ALTER TABLE `party`
  ADD PRIMARY KEY (`party_id`);

--
-- Indexes for table `pet`
--
ALTER TABLE `pet`
  ADD PRIMARY KEY (`pet_id`);

--
-- Indexes for table `quest`
--
ALTER TABLE `quest`
  ADD PRIMARY KEY (`char_id`,`quest_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `sc_data`
--
ALTER TABLE `sc_data`
  ADD KEY `account_id` (`account_id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `skill`
--
ALTER TABLE `skill`
  ADD PRIMARY KEY (`char_id`,`id`),
  ADD KEY `char_id` (`char_id`);

--
-- Indexes for table `skill_homunculus`
--
ALTER TABLE `skill_homunculus`
  ADD PRIMARY KEY (`homun_id`,`id`),
  ADD KEY `homun_id` (`homun_id`);

--
-- Indexes for table `storage`
--
ALTER TABLE `storage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auction`
--
ALTER TABLE `auction`
  MODIFY `auction_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cart_inventory`
--
ALTER TABLE `cart_inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `char`
--
ALTER TABLE `char`
  MODIFY `char_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150004;
--
-- AUTO_INCREMENT for table `guild`
--
ALTER TABLE `guild`
  MODIFY `guild_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guild_storage`
--
ALTER TABLE `guild_storage`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `homunculus`
--
ALTER TABLE `homunculus`
  MODIFY `homun_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `account_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2000002;
--
-- AUTO_INCREMENT for table `mail`
--
ALTER TABLE `mail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `memo`
--
ALTER TABLE `memo`
  MODIFY `memo_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mercenary`
--
ALTER TABLE `mercenary`
  MODIFY `mer_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `party`
--
ALTER TABLE `party`
  MODIFY `party_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pet`
--
ALTER TABLE `pet`
  MODIFY `pet_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `storage`
--
ALTER TABLE `storage`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 24-Fev-2016 às 02:18
-- Versão do servidor: 5.7.11
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cp`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cp_bruteforce`
--

CREATE TABLE `cp_bruteforce` (
  `action_id` int(11) NOT NULL,
  `user` varchar(24) NOT NULL DEFAULT '',
  `IP` varchar(20) NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT '0',
  `ban` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cp_links`
--

CREATE TABLE `cp_links` (
  `cod` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `url` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `size` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `claimed` tinyint(1) NOT NULL,
  `recipient` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_namechange`
--

CREATE TABLE `log_namechange` (
  `id` int(10) UNSIGNED NOT NULL,
  `fecha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `old_name` varchar(30) NOT NULL DEFAULT '',
  `new_name` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vote_point`
--

CREATE TABLE `vote_point` (
  `account_id` int(11) NOT NULL DEFAULT '0',
  `point` int(11) NOT NULL DEFAULT '0',
  `last_vote1` int(11) NOT NULL DEFAULT '0',
  `last_vote2` int(11) NOT NULL DEFAULT '0',
  `last_vote3` int(11) NOT NULL DEFAULT '0',
  `last_vote4` int(11) NOT NULL DEFAULT '0',
  `last_vote5` int(11) NOT NULL DEFAULT '0',
  `date` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cp_bruteforce`
--
ALTER TABLE `cp_bruteforce`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `user` (`user`),
  ADD KEY `IP` (`IP`);

--
-- Indexes for table `cp_links`
--
ALTER TABLE `cp_links`
  ADD PRIMARY KEY (`cod`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_namechange`
--
ALTER TABLE `log_namechange`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vote_point`
--
ALTER TABLE `vote_point`
  ADD PRIMARY KEY (`account_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cp_bruteforce`
--
ALTER TABLE `cp_bruteforce`
  MODIFY `action_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cp_links`
--
ALTER TABLE `cp_links`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log_namechange`
--
ALTER TABLE `log_namechange`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

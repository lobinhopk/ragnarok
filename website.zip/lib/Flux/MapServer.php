<?php
require_once 'Flux/BaseServer.php';

/**
 * Represents an rAthena Map Server.
 */
class Flux_MapServer extends Flux_BaseServer {
	
}
?>
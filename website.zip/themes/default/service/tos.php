<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2><?php echo htmlspecialchars(Flux::message('TermsHeading')) ?></h2>
<p style="font-style: italic"><?php echo htmlspecialchars(Flux::message('TermsInfo')) ?></p>
<p class="note"><?php echo htmlspecialchars(sprintf(Flux::message('TermsInfo2'), __FILE__)) ?></p>